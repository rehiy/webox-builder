#!/bin/bash

##################################################
# define something

basedir=/var/data/backup_$(date +%Y%m)
backdir=$basedir/$(date +%d)
if [ ! -d $backdir ]; then
	mkdir -p $backdir
fi

# arg: host user password
sqldump() {
	echo backup mysql: $2@$1 ...
	mysqldump --all-databases --host=$1 --user=$2 --password=$3 | gzip >$backdir/sql-$1-$2.gz
}

# arg: bakupname scrdir
dirback() {
	echo backup files: $3 ...
	if [ $(date +%d) -eq 1 ]; then
		rm -rf $basedir/$1.snap
	fi
	tar -g $basedir/$1.snap -zvcPf $backdir/dir-$1.tar.gz $2
}


##################################################
# backup progress

dirback var_www /var/www
sqldump 172.26.8.11 xcnet password
