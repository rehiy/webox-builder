
wb_pack_once() {

	wb_aptitude zlib1g-dev libmysqlclient-dev \
		libltdl-dev libpcre3-dev libssl-dev libcurl4-openssl-dev \
		libmcrypt-dev libxml2-dev libfreetype6-dev libjpeg62-dev libpng12-dev

}

wb_pack_make() {

	make clean | true

	./configure \
		--prefix=/usr \
		--bindir=/usr/bin --sbindir=/usr/sbin \
		--localstatedir=/var --mandir=/usr/share/man \
		--sysconfdir=/etc/php --with-config-file-path=/etc/php \
		--enable-fpm --disable-cli --disable-rpath --without-pear \
		--enable-mbstring --enable-zip --with-zlib --with-mcrypt \
		--enable-exif --enable-sockets --enable-ftp --with-curl --with-openssl \
		--with-freetype-dir --with-gd --with-jpeg-dir --with-png-dir --enable-gd-native-ttf \
		--with-gettext --with-mysql --with-mysqli --with-pdo-mysql --enable-sqlite-utf8

	make
	make install

}

wb_pack_inst() {

	wb_package_install_bin '/usr/sbin/php-fpm'

	wb_package_install_def 'php'

}
